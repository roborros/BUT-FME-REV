// REV ADC
#pragma config FOSC = HSMP          // Oscillator Selection bits (HS oscillator (medium power 4-16 MHz))
#pragma config PLLCFG = ON          // 4X PLL Enable (Oscillator used directly)
#pragma config PRICLKEN = ON        // Primary clock enable bit (Primary clock is always enabled)
#pragma config WDTEN = OFF          // Watchdog Timer Enable bits (Watch dog timer is always disabled. SWDTEN has no effect.)

#include <xc.h>
#include <stdio.h>
#include <stdint.h>

#define _XTAL_FREQ 32E6

void putch(unsigned char data);

void main(void) {
     
    ANSELA |= (1 << 5);             //AN4
    ANSELE = 0b1;                   //AN5
    
    TRISCbits.TRISC6 = 1;   // TX pin jako vstup
    TRISCbits.TRISC7 = 1;   // rx pin jako vstup
   
    /*baudrate*/
    SPBRG1 = 51;              // (32_000_000 / (64 * 9600)) - 1
    
    TXSTA1bits.SYNC = 0;      // nastaveni asynchroniho modu
    RCSTA1bits.SPEN = 1;      // zapnuti UART
    TXSTA1bits.TXEN = 1;      // zapnuti TX
    RCSTA1bits.CREN = 1;      // zapnuti RX 
    
    ADCON2bits.ADFM = 1;            //right justified
    ADCON2bits.ADCS = 0b110;        //Fosc/64
    ADCON2bits.ACQT = 0b110;        //16
    ADCON0bits.ADON = 1;            //ADC zapnout
    
    uint16_t pot1, pot2;                    // promenna pro vysledek prevodu

    while(1){
        
        ADCON0bits.CHS = 5;                         // kanal AN5
        GODONE = 1;                                 // spustit aproximaci
        while(GODONE);                              // cekam nez je hotovo
        pot1 = (uint16_t)((ADRESH << 8) | ADRESL);  // cteni vysledku
        
        uint32_t mV1 = ((uint32_t)pot1*3300)>>10;
        
        ADCON0bits.CHS = 4;                         // kanal AN4
        GODONE = 1;                                 // spustit aproximaci
        while(GODONE);                              // cekam nez je hotovo
        pot2 = (uint16_t)((ADRESH << 8) | ADRESL);  // cteni vysledku
        
        uint32_t mV2 = ((uint32_t)pot2*3300)>>10;
        
        printf("%f,%f,\r", (float)mV1/1000, (float)mV2/1000);
        
        __delay_ms(33);
    }
    
    return;
}


void putch(unsigned char data){
    while(!TX1IF);
    TXREG1 = data;
}