#ifndef UART_H
#define	UART_H

void uart_init(void);
void putch(unsigned char data);

#endif	/* UART_H */

