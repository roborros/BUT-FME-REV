// REV PWM
#pragma config FOSC =       HSMP        // Oscillator Selection bits (HS oscillator (medium power 4-16 MHz))
#pragma config PLLCFG =     ON          // 4X PLL Enable (Oscillator multiplied by 4)
#pragma config WDTEN =      OFF         // watchdog off

#include <xc.h>
#include <stdint.h>

#define PWMOUT LATBbits.LATB5

void main(void) {
    
    TRISBbits.TRISB5 = 0;
    
    uint8_t triang;
    
    uint8_t duty = 128;
    
    while(1){
        
        triang++;
        
        if(triang < duty){
            PWMOUT = 1;
        }else{
            PWMOUT = 0;
        }
        
        
    }
    
    
    return;
}
