// REV PWM
#pragma config FOSC =       HSMP        // Oscillator Selection bits (HS oscillator (medium power 4-16 MHz))
#pragma config PLLCFG =     ON          // 4X PLL Enable (Oscillator multiplied by 4)
#pragma config WDTEN =      OFF         // watchdog off

#pragma config CCP3MX = PORTB5  // P3A/CCP3 Mux bit (P3A/CCP3 input/output is multiplexed with RB5)

#include <xc.h>
#include <stdint.h>
#include <stdio.h>
#include "lcd.h"

#define _XTAL_FREQ 32000000

volatile uint16_t prev_us = 0;
volatile uint16_t per_us = 0;

void __interrupt() h_isr(void){
    
    if(CCP3IF && CCP3IE){
        per_us = CCPR3 - prev_us;
        prev_us = CCPR3;
        CCP3IF = 0;
    }

}

void main(void) {
    
    __delay_ms(100);
    LCD_Init(); 
       
    TRISBbits.TRISB5 = 1;
    ANSELB = 0;
    
    T1CONbits.TMR1CS = 0b00;        // zdroj casovace 1
    T1CONbits.T1CKPS = 0b11;        // nastaveni delicky  
    TMR1 = 0;
    
    CCP3CONbits.CCP3M = 0b0101;
    CCPTMRS0bits.C3TSEL = 0b00;
    CCP3IE = 1;
    CCP3IF = 0;
    
    PEIE = 1;
    GIE = 1;
    
    TMR1ON = 1;
    
    char lcd_str[17];
   
    while(1){
        

     
        sprintf(lcd_str, "per: %d    ", per_us);
        LCD_ShowString(1, lcd_str);
        __delay_ms(40);
    }
    
    return;
}
