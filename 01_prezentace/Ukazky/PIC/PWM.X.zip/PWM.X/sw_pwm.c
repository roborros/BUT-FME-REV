// REV PWM
#pragma config FOSC =       HSMP        // Oscillator Selection bits (HS oscillator (medium power 4-16 MHz))
#pragma config PLLCFG =     ON          // 4X PLL Enable (Oscillator multiplied by 4)
#pragma config WDTEN =      OFF         // watchdog off


#include <xc.h>
#include <stdint.h>


#define PWMOUT LATBbits.LATB5

volatile uint8_t duty = 100;

void __interrupt() H_ISR(void){

    if(ADIF && ADIE){
    
        duty = ADRESH;
        GODONE = 1;
        ADIF = 0;
        
    }

}

void main(void) {
    
    TRISBbits.TRISB5 = 0;
    
    ANSELA |= (1 << 5);             //AN4
    ANSELE = 0b1;                   //AN5
 
    ADCON2bits.ADFM = 0;            
    ADCON2bits.ADCS = 0b001;        //Fosc/64
    ADCON2bits.ACQT = 0b100;        //16
    ADCON0bits.ADON = 1;            //ADC zapnout
    ADCON0bits.CHS = 5;
    ADIF = 0;
    ADIE = 1;
    
    PEIE = 1;
    GIE = 1;
    
    T2CONbits.T2CKPS = 0b11; // div 16
    PR2 = 255;
    T2CONbits.TMR2ON = 1;
   
    GODONE = 1;
    
    while (1){
        
        if (TMR2 < duty){
            PWMOUT = 1;
        }
        else{
            PWMOUT = 0;
        }
        
    }
    
    return;
}
