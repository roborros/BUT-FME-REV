// REV INTERRUPT
#pragma config FOSC = HSMP      // Oscillator Selection bits (HS oscillator (medium power 4-16 MHz))
#pragma config PLLCFG = ON      // 4X PLL Enable (Oscillator multiplied by 4)
#pragma config WDTEN = OFF      // Watchdog Timer Enable bits (Watch dog timer is always disabled. SWDTEN has no effect.)

#include <stdint.h>
#include <xc.h>

#define _XTAL_FREQ 32E6             // definice fosc pro knihovnu
#define LED1 LATDbits.LATD2          // ledka
#define LED2 LATDbits.LATD6          // ledka
#define PR 200                      // hodnota timeru

volatile uint32_t millis = 0;

uint32_t get_millis(void);

void __interrupt() T2_ISR_(void){
    if (TMR2IF && TMR2IE ){             // kontrola priznaku IF (interrupt flag) a IE (interrupt enabled)   
        millis++;
        TMR2IF = 0;                     // smazani IF jinak nedojde k dalsimu zavolani (bezpecnostni prvek, preruseni je zamaskovano)
    }
}

void init(void){
    
    TRISDbits.TRISD2 = 0;           // RD2 jako vystup
    TRISCbits.TRISC0 = 1;
    TRISDbits.TRISD6 = 0;
    
    T2CONbits.T2CKPS = 0b01;        // deleni /4
    PR2 = 200;                      // hodnota period registru
    T2CONbits.T2OUTPS = 0b1001;     // jednou za 10 preteceni
    TMR2IE = 1;                     // povoleni preruseni pro TMR1
    TMR2IF = 0;                     // smazani priznaku (pro jistotu)
    PEIE = 1;                       // povoleni preruseni od periferii
    TMR2ON = 1;                     // spusteni TMR1
    GIE = 1;                        // globalni povoleni preruseni
}

void main(void) {
    
    init();                         // provedeni inicializace
   
    uint32_t prev_time = get_millis();
    
    while(1){
        
        if((get_millis() - prev_time) >= 500){
            prev_time = get_millis();
            LED1 ^= 1;
        }
        
        if(PORTCbits.RC0){
            LED2 = 0;
        }
        else{
            LED2 = 1;
        }
        
    }
}

uint32_t get_millis(void){
    return millis;
}