// REV INTERRUPT
#pragma config FOSC = HSMP      // Oscillator Selection bits (HS oscillator (medium power 4-16 MHz))
#pragma config PLLCFG = OFF     // 4X PLL Enable (Oscillator OFF)
#pragma config WDTEN = OFF      // Watchdog Timer Enable bits (Watch dog timer is always disabled. SWDTEN has no effect.)

#include <xc.h>

#define _XTAL_FREQ 8E6               // definice fosc pro knihovnu
#define BTN1 PORTCbits.RC0           // tlacitko 1
#define LED1 LATDbits.LATD2          // ledka
#define LED6 LATDbits.LATD6          // ledka

void init(void){
    
    TRISDbits.TRISD2 = 0;           // RD2 jako vystup
    TRISDbits.TRISD6 = 0;           // RD2 jako vystup
    TRISCbits.TRISC0 = 1;           // RC0 jako vstup 
}

void main(void) {
    init();                         // provedeni inicializace
    
    while(1){
        
        if(BTN1){
            LED6 = 0;
        }else{
            LED6 = 1;
        }
        
        LED1 ^= 1; 
        
        __delay_ms(1000);

    }
}