// REV INTERRUPT
#pragma config FOSC = HSMP      // Oscillator Selection bits (HS oscillator (medium power 4-16 MHz))
#pragma config PLLCFG = ON      // 4X PLL Enable (Oscillator multiplied by 4)
#pragma config PRICLKEN = ON    // Primary clock enable bit (Primary clock is always enabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enable bit (Fail-Safe Clock Monitor disabled)
#pragma config WDTEN = OFF      // Watchdog Timer Enable bits (Watch dog timer is always disabled. SWDTEN has no effect.)

#include <xc.h>

#define _XTAL_FREQ 32E6             // definice fosc pro knihovnu
#define LED LATDbits.LATD2          // ledka
#define DELAY (0xFFFF - 49999)      // hodnota timeru


void __interrupt() T1_ISR(void){
     
    if (TMR1IF && TMR1IE ){             // kontrola priznaku IF (interrupt flag) a IE (interrupt enabled)   
        
        TMR1 = DELAY;                   // nastaveni registru timeru (preruseni vzvolava preteceni registru)
        LED ^= 1;
        LATBbits.LATB5 ^= 1;
        TMR1IF = 0;                     // smazani IF jinak nedojde k dalsimu zavolani (bezpecnostni prvek, preruseni je zamaskovano)
    }
}

void init(void){
    
    TRISDbits.TRISD2 = 0;           // RD2 jako vystup
    TRISBbits.TRISB5 = 0;           // RB5 jako vystup
    
    T1CONbits.TMR1CS = 0b00;        // zdroj casovace 1
    T1CONbits.T1CKPS = 0b11;        // nastaveni delicky                                             
    TMR1IE = 1;                     // povoleni preruseni pro TMR1
    TMR1IF = 0;                     // smazani priznaku (pro jistotu)
    PEIE = 1;                       // povoleni preruseni od periferii
    TMR1ON = 1;                     // spusteni TMR1
    GIE = 1;                        // globalni povoleni preruseni
}

void main(void) {
    init();                         // provedeni inicializace
    
    while(1){
        __delay_ms(100);            // cekani 100ms s knihovni funkci
    }
}