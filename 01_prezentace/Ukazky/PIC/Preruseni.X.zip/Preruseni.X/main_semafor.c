// REV INTERRUPT
#pragma config FOSC = HSMP      // Oscillator Selection bits (HS oscillator (medium power 4-16 MHz))
#pragma config PLLCFG = ON      // 4X PLL Enable (Oscillator multiplied by 4)
#pragma config PRICLKEN = ON    // Primary clock enable bit (Primary clock is always enabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enable bit (Fail-Safe Clock Monitor disabled)
#pragma config WDTEN = OFF      // Watchdog Timer Enable bits (Watch dog timer is always disabled. SWDTEN has no effect.)
#include <xc.h>

#define _XTAL_FREQ 32E6             // definice fosc pro knihovnu
#define LED LATDbits.LATD2          // ledka
#define DELAY (0xFFFF - 999)       // hodnota timeru

volatile unsigned char flag = 0;             // globalni promenna 

void __interrupt() T1_ISR_HANDLER(void){
    
    volatile unsigned static int i = 0;      // staticka promenna nelze pouzit mimo ISR
    
    if (TMR1IF && TMR1IE ){                  // kontrala priznaku a povoleni
        if (i >= 500) {
            flag = 1;                        // nastaveni vlajky
            i = 0;
        }  
        i++;
        LATBbits.LATB5 ^= 1;
        TMR1 = DELAY;                        // nastaveni registru TMR1
        TMR1IF = 0;
    }
}

void init(void){
    
    /* vyber pinu jako vystupy */
    TRISBbits.TRISB5 = 0;
    TRISDbits.TRISD2 = 0;

    T1CONbits.TMR1CS = 0b00;
    T1CONbits.T1CKPS = 0b11;
    GIE = 1;
    PEIE = 1;
    TMR1IE = 1;
    TMR1IF = 0;
    TMR1ON = 1;
}

void main(void) {
    
    init(); // provedeni inicializace
    
    /* hlavni smycka */
    while(1){
        
        if (flag) {
            LED ^= 1;
            flag = 0;
        }
    }
}