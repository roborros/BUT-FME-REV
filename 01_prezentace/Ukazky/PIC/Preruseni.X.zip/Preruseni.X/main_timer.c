// REV INTERRUPT
#pragma config FOSC = HSMP      // Oscillator Selection bits (HS oscillator (medium power 4-16 MHz))
#pragma config PLLCFG = OFF     // 4X PLL Enable (Oscillator OFF)
#pragma config WDTEN = OFF      // Watchdog Timer Enable bits (Watch dog timer is always disabled. SWDTEN has no effect.)

#include <xc.h>

#define _XTAL_FREQ 8E6               // definice fosc pro knihovnu
#define LED1 LATDbits.LATD2          // ledka

void init(void){
    
    TRISDbits.TRISD2 = 0;           // RD2 jako vystup
    TRISBbits.TRISB5 = 0;           // RB5 jako vystup 
    
    T1CONbits.TMR1CS = 0b00;        // zdroj casovace 1
    T1CONbits.T1CKPS = 0b11;        // nastaveni delicky                                             
    TMR1ON = 1;                     // spusteni TMR1
}

void main(void) {
    init();                         // provedeni inicializace
    
    while(1){
        if(TMR1 >= 50000){          // kontrola registru casovace
            LATBbits.LATB5 ^= 1;    // prevraceni pinu RB5
            LED1 ^= 1;              // prevraceni pinu RD2 (led 1)
            TMR1 = 0;               // vznulovani registru casovace
        }
    }
}