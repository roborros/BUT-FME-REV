// REV INTERRUPT
#pragma config FOSC = HSMP      // Oscillator Selection bits (HS oscillator (medium power 4-16 MHz))
#pragma config PLLCFG = ON      // 4X PLL Enable (Oscillator multiplied by 4)
#pragma config WDTEN = OFF      // Watchdog Timer Enable bits (Watch dog timer is always disabled. SWDTEN has no effect.)

#include <xc.h>

#define _XTAL_FREQ 32E6                 // definice fosc pro knihovnu
#define LED1 LATDbits.LATD2             // ledka
#define LED2 LATDbits.LATD3             // ledka
#define LED6 LATDbits.LATD6             // ledka
#define PR 200                          // hodnota pr
#define DELAY (0xFFFF - 49999)          // hodnota timeru pro isr



void __interrupt(high_priority) T1_ISR(void){
    
    if (TMR1IF && TMR1IE ){             // kontrola priznaku IF (interrupt flag) a IE (interrupt enabled)  
        TMR1 = DELAY;
        LED1 ^= 1;
        TMR1IF = 0;                     // smazani IF jinak nedojde k dalsimu zavolani (bezpecnostni prvek)
        }
}

void __interrupt(low_priority) T2_ISR(void){
    volatile static int count=0;
    if (TMR2IF && TMR2IE ){             // kontrola priznaku IF (interrupt flag) a IE (interrupt enabled)   
        if (count >= 500){
            LED2 ^= 1;
            count = 0;
        }
        count++;
        TMR2IF = 0;                     // smazani IF jinak nedojde k dalsimu zavolani (bezpecnostni prvek)
    }
}

void init(void){
    
    TRISDbits.TRISD2 = 0;           // RD2 jako vystup
    TRISDbits.TRISD3 = 0;           // RD3 jako vystup
    TRISDbits.TRISD6 = 0;
    TRISCbits.TRISC0 = 1;
    
    IPEN = 1;                       // rozliseni priorit
    // timer 2
    T2CONbits.T2CKPS = 0b01;        // deleni /4
    PR2 = PR;                      // hodnota period registru
    T2CONbits.T2OUTPS = 0b1001;     // jednou za 10 preteceni
    TMR2IP = 0;                     // low priorita
    TMR2IE = 1;                     // povoleni preruseni pro TMR1
    TMR2IF = 0;                     // smazani priznaku (pro jistotu)
    // timer 1
    T1CONbits.TMR1CS = 0b00;        // timer 1 zdroj
    T1CONbits.T1CKPS = 0b11;        // timer1 delicka
    TMR1IE = 1;
    TMR1IF = 0;  
    TMR2ON = 1;                     // spusteni TMR1
    TMR1ON = 1;
    GIEL = 1;                       // povoleni preruseni 
    GIEH = 1;                       // povoleni preruseni
}

void main(void) {
    init();                         // provedeni inicializace
    
    while(1){
        
        if(PORTCbits.RC0){
            LED6 = 0;
        }
        else{
            LED6 = 1;
        }
    }
}