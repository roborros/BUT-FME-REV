// I2C
#pragma config FOSC =   HSMP          // Oscillator Selection bits (HS oscillator (medium power 4-16 MHz))
#pragma config PLLCFG = ON            // 4X PLL Enable (Oscillator multiplied by 4)
#pragma config WDTEN = OFF            // Watchdog Timer Enable bits (WDT is always enabled. SWDTEN bit has no effect)

#include <stdio.h>
#include <stdint.h>
#include <xc.h>

#define _XTAL_FREQ 32E6
#define LCD_I2C_ADDR 0x7c

void I2C_Start(void) {
    SSP2CON2bits.SEN = 1; 
    while(SSP2CON2bits.SEN);
    SSP2IF = 0;
}

void I2C_Stop(void) {
    SSP2CON2bits.PEN = 1; 
    while(SSP2CON2bits.PEN);
}

void I2C_Write(unsigned char data){
    
    SSP2BUF = data;
    while(SSP2STATbits.BF);
    while(!SSP2IF);
    SSP2IF = 0;
    
}

void LCD_ShowString(char lineNum, char textData[])
{
    unsigned char i;
    i = 0;
    
    I2C_Start();
    
    I2C_Write(0x7c);

    I2C_Write(0x80);
    
    if(lineNum == 1){
        I2C_Write(0x80);
    }
    else if (lineNum == 2){
        I2C_Write(0xC0);
    }
    
    I2C_Write(0x40);
    
    for (i = 0; i<16; i++){
        I2C_Write(textData[i]);
    }
    
    I2C_Stop();
}

void LCD_Command(uint8_t cmd) {
    I2C_Start();
    I2C_Write(LCD_I2C_ADDR); // z�pis
    I2C_Write(0x00); 
    I2C_Write(cmd);
    I2C_Stop();
}


void init(void){
    
    ANSELDbits.ANSD0 = 0;
    ANSELDbits.ANSD1 = 0;
    
    TRISDbits.TRISD0 = 1;           // pin as input
    TRISDbits.TRISD1 = 1;           // pin as input
    TRISAbits.TRISA0 = 0;           // pin as input
    LATAbits.LATA0 = 1;
    
    
    SSP2CON1bits.SSPM = 0b1000;     // I2C Master mode
    SSP2ADD = 19; 
    SSP2CON1bits.SSPEN = 1;         // enable
    
    __delay_ms(40);
    
    LCD_Command(0x38); __delay_ms(1);  // Function set
    LCD_Command(0x39); __delay_ms(1);  // Extended instruction set
    LCD_Command(0x17); __delay_ms(1);  // OSC Frequency/Bias
    LCD_Command(0x7A); __delay_ms(1);  // Contrast set (ni??� ?�st)
    LCD_Command(0x5E); __delay_ms(1);  // Contrast/Icon (vy??� ?�st)
    LCD_Command(0x6B); __delay_ms(200);// Follower control (del?� prodleva!)
    LCD_Command(0x0C); __delay_ms(1);  // Display ON
    LCD_Command(0x01); __delay_ms(2);  // Clear display
    LCD_Command(0x02); __delay_ms(1);  // Entry mode set
    
    __delay_ms(5);
}


void main(void) {
    
    init();
    
    char str[32];
    uint8_t i = 0;
    
    while(1){
        
        sprintf(str, "Iterace: %d         ", i++);
        
        LCD_ShowString(1, str);
        
        __delay_ms(500);

    }
}
