// DAC
#pragma config FOSC =   HSMP          // Oscillator Selection bits (HS oscillator (medium power 4-16 MHz))
#pragma config PLLCFG = ON            // 4X PLL Enable (Oscillator multiplied by 4)
#pragma config WDTEN = OFF            // Watchdog Timer Enable bits (WDT is always enabled. SWDTEN bit has no effect)

#include <stdint.h>
#include <xc.h>

#define _XTAL_FREQ 32E6         // definice fosc pro knihovnu
#define DAC_SS LATB3            // DAC slave select pin
#define DAC_CH1 0b00110000      // kanal 1/B
#define DAC_CH2 0b10110000      // kanal 2/A


void init(void){
    
    /* vyber pinu jako vystupy */
    TRISCbits.TRISC3 = 0;
    TRISCbits.TRISC5 = 0;
    TRISBbits.TRISB3 = 0;
 
    LATBbits.LATB3 = 1;         // DAC SS off
    
    SSP1CON1bits.SSPM = 0b1010; // SPI clock
    SSP1ADD = 199;              // frekvence
    SSP1STATbits.CKE = 1;
    SSP1CON1bits.SSPEN = 1;     // SPI zapnuto
}
void SPIWrite(uint8_t channel ,uint8_t data);

void main(void) {
    init(); // provedeni inicializace
    
    uint8_t i = 0;
    uint8_t  j = 0;
         
    /* hlavni smycka */
    while(1){

            SPIWrite(DAC_CH1,i++);  
            if(j == 128) j=0;
            
            __delay_us(100);
        }
}
/* funkce zapisu SPI funkce zapisuje dva bajty za sebou */
void SPIWrite(uint8_t channel ,uint8_t data){
    
    uint8_t msb, lsb, flush;
    msb = (channel | (data>>4));        // prvni bajt
    lsb = (data<<4) & 0xFF;             // druhy bajt
    DAC_SS = 0;                         // slave select
    PIR1bits.SSPIF = 0;                 // vynulovani priznaku SPI
    SSPBUF = msb;                       // zapis do bufferu
    while(PIR1bits.SSPIF == 0)NOP();    // pockat nez SPI posle prvni bajt
    
    PIR1bits.SSPIF = 0;                 // vynulovani priznaku SPI
    SSPBUF = lsb;                       // zapis do bufferu
    while(PIR1bits.SSPIF == 0)NOP();    // pockat nez SPI posle druhy bajt
    
    DAC_SS = 1;                         // vypnout slave select
    flush = SSPBUF;                     // vycteni bufferu
    
}