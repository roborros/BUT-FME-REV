// REV INTERRUPT
#pragma config FOSC = INTIO67   // Oscillator Selection bits (Internal oscillator block)
#pragma config PLLCFG = ON      // 4X PLL Enable (Oscillator multiplied by 4)
#pragma config WDTEN = OFF      // Watchdog Timer Enable bits (Watch dog timer is always disabled. SWDTEN has no effect.)

#include <xc.h>

#define LED LATDbits.LATD2          // ledka
#define DELAY (0xFFFF - 999)       // hodnota timeru pro 1 ms

volatile unsigned char flag = 0;             // globalni promenna 

void __interrupt() T1_ISR(void){
    
    volatile unsigned static int i = 0;      // staticka promenna nelze pouzit mimo ISR
    if (TMR1IF && TMR1IE ){         // kontrala priznaku a povoleni
        if (i >= 500) {
            flag = 1;               // nastaveni vlajky
            i = 0;
        }  
    i++;
    TMR1 = DELAY;                   // nastaveni registru TMR1
    TMR1IF = 0;
    }
}

void init(void){
    
    OSCCONbits.IRCF = 0b100;
    OSCTUNEbits.PLLEN = 1;
    while(!OSCCONbits.HFIOFS){};
    
    TRISDbits.TRISD2 = 0;
    T1CONbits.TMR1CS = 0b00;
    T1CONbits.T1CKPS = 0b11;
    GIE = 1;
    PEIE = 1;
    TMR1IE = 1;
    TMR1IF = 0;
    TMR1ON = 1;
}

void main(void) {
    init(); // provedeni inicializace
    
    while(1){
        if (flag) {
            LED ^= 1;
            flag = 0;
        }
    }
}