// WDT_SLEEP
#pragma config FOSC =   HSMP        // Oscillator Selection bits (HS oscillator (medium power 4-16 MHz))
#pragma config PLLCFG = OFF         // 4X PLL Enable (Oscillator multiplied by 4)
#pragma config PRICLKEN = ON        // Primary clock enable bit (Primary clock is always enabled)

// nastaveni WDT
#pragma config WDTEN = ON           // Watchdog Timer Enable bits (WDT is always enabled. SWDTEN bit has no effect)
#pragma config WDTPS = 256          // Watchdog Timer Postscale Select bits (1:256)

#include <xc.h>

#define BTN1    PORTCbits.RC0
#define LED1    LATDbits.LATD2

void main(void) {
    
    //GPIO
    TRISD = 0b10000011;     // LEDs: 2..6 out
    TRISC = 0b00000001;     // RC0 BTN1, RC4 LED
    ANSELC = 0;
    ANSELD = 0;
    
    // Zhasnu ledky
    LATD2 = 1;
    LATD3 = 1;
    LATC4 = 1;
    LATD4 = 1;
    LATD5 = 1;
    LATD6 = 1;
    
    IDLEN = 0;
    
    while(1){
        LED1 ^= 1;
        __asm("SLEEP");
    }
    return;
}