#pragma config FOSC = HSMP      // Externi oscilator
#pragma config PLLCFG = ON      // 4X PLL 

// nastaveni WDT
#pragma config WDTEN = ON           // Watchdog Timer Enable bits (WDT is always enabled. SWDTEN bit has no effect)
#pragma config WDTPS = 256          // Watchdog Timer Postscale Select bits (1:256)

#include <xc.h>                 // pro prekladac XC8

#define LED1    LATDbits.LATD2

void __interrupt() ISR(){    
    if(RC1IF && RC1IE){
        TXREG1 = RCREG1;
    }
}

/*--------main--------*/
int main(void) {
    
    TRISDbits.TRISD2 = 0;
    
    ANSELC = 0;
    TRISCbits.TRISC6 = 1;   // TX pin jako vstup
    TRISCbits.TRISC7 = 1;   // rx pin jako vstup
   
    /*baudrate*/
    SPBRG1 = 51;              // (32_000_000 / (64 * 9600)) - 1
    
    TXSTA1bits.SYNC = 0;      // nastaveni asynchroniho modu
    RCSTA1bits.SPEN = 1;      // zapnuti UART
    TXSTA1bits.TXEN = 1;      // zapnuti TX
    RCSTA1bits.CREN = 1;      // zapnuti RX 
    
    RC1IE = 1;                // zap  preruseni od RCREG
    PEIE = 1;                // preruseni od periferii    
    GIE = 1;                 // globalni preruseni
    
    IDLEN = 1;
    
    
    while(1){
        LED1 ^= 1;
        __asm("SLEEP");
    }
}