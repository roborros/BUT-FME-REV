// uart
#pragma config FOSC = HSMP      // Externi oscilator
#pragma config PLLCFG = ON      // 4X PLL 
#pragma config WDTEN = OFF      // Watchdog Timer OFF

#include <xc.h>             //-- pro prekladac XC8
#include <stdio.h>          //   pro printf
#include <string.h>          

#define _XTAL_FREQ 32E6

void putch(unsigned char data);
void uart_write_arr(char *buf, int len);

/*--------main--------*/
int main(void) {
    
    ANSELC = 0x00;          // vypnuti analogovych funkci na PORTC
    TRISD = 0x00;           // PORTD jako vystup
    TRISCbits.TRISC6 = 1;   // TX pin jako vstup
    TRISCbits.TRISC7 = 1;   // rx pin jako vstup
   
    /*baudrate*/
    SPBRG1 = 51;              // (32_000_000 / (64 * 9600)) - 1
    
    TXSTA1bits.SYNC = 0;      // nastaveni asynchroniho modu
    RCSTA1bits.SPEN = 1;      // zapnuti UART
    TXSTA1bits.TXEN = 1;      // zapnuti TX
    RCSTA1bits.CREN = 1;      // zapnuti RX 
    
    char str[32];
    char count = 0;
    
    while(1){
        __delay_ms(500);
        uart_write_arr("Ahoj\n", 5);
        __delay_ms(500);
        
        sprintf(str,"Hodnota => %d \n", count++);
        
        uart_write_arr(str, strlen(str));
        
    }
}

void uart_write_arr(char *buf, int len){
    
    for(int i=0; i<len; i++){
    
        putch(buf[i]);
        
    }
    
}

void putch(unsigned char data){
    while(!TX1IF);
    TXREG1 = data;
}