// uart
#pragma config FOSC = HSMP      // Externi oscilator
#pragma config PLLCFG = ON      // 4X PLL 
#pragma config WDTEN = OFF      // Watchdog Timer OFF

#include <xc.h>                 // pro prekladac XC8
#include <string.h>

#define _XTAL_FREQ 32E6


void gpio_init(void);
void gpio_all_leds(char in);

typedef struct{

    char data[32];
    char idx;
    char full;

}uart_msg_t;

volatile uart_msg_t msg;

void __interrupt() RC_ISR(){
    
    if(RC1IF && RC1IE){
        
        char rchar = RCREG1;
        
        if(msg.full == 0){
        
            if(rchar != '.'){
                msg.data[msg.idx++] = rchar;
                if(msg.idx > 31){
                    msg.idx = 0;
                }
            }
            else{
                msg.data[msg.idx] = '\0';
                msg.idx = 0;
                msg.full = 1;
            }
        }
    }
}

/*--------main--------*/
int main(void) {
    
    gpio_init();
    
    ANSELC = 0x00;          // vypnuti analogovych funkci na PORTC
    TRISD = 0x00;           // PORTD jako vystup
    TRISCbits.TRISC6 = 1;   // TX pin jako vstup
    TRISCbits.TRISC7 = 1;   // rx pin jako vstup
   
    /*baudrate*/
    SPBRG1 = 51;              // (32_000_000 / (64 * 9600)) - 1
    
    TXSTA1bits.SYNC = 0;      // nastaveni asynchroniho modu
    RCSTA1bits.SPEN = 1;      // zapnuti UART
    TXSTA1bits.TXEN = 1;      // zapnuti TX
    RCSTA1bits.CREN = 1;      // zapnuti RX 
    
    RC1IE = 1;                // zap  preruseni od RCREG
    PEIE = 1;                 // preruseni od periferii    
    GIE = 1;                  // globalni preruseni
    
    msg.full = 0;
    msg.idx = 0;
    
    
    while(1){
        
        if(msg.full == 1){
            
            if (strcmp(msg.data, "AON") == 0){
                gpio_all_leds(0x00);
            }
            
            if (strcmp(msg.data, "AOFF") == 0){
                gpio_all_leds(0xFF);
            }
            
            msg.full = 0;
        }
                             
    }
}

void gpio_init(void){
    
    
    // Nastaveni pinu pro LED jako vystup
    TRISDbits.TRISD2 = 0;
    TRISDbits.TRISD3 = 0;
    TRISCbits.TRISC4 = 0;
    TRISDbits.TRISD4 = 0;
    TRISDbits.TRISD5 = 0;
    TRISDbits.TRISD6 = 0;

    LATD2 = 1;        
    LATD3 = 1;     
    LATC4 = 1;     
    LATD4 = 1;     
    LATD5 = 1;     
    LATD6 = 1;      
    
}


void gpio_all_leds(char in){
    LATD2 = in & 1;             //LED0
    LATD3 = in & 2 ? 1 : 0;     //LED1
    LATC4 = in & 4 ? 1 : 0;     //LED2
    LATD4 = in & 8 ? 1 : 0;     //LED3
    LATD5 = in & 16 ? 1 : 0;    //LED4
    LATD6 = in & 32 ? 1 : 0;    //LED5
}