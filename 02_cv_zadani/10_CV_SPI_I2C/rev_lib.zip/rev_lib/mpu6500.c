#include "mpu6500.h"

bool mpu6050_init(mpu6050_dev_t *dev)
{
    dev->write_reg(dev->addr, MPU6500_REG_PWR_MGMT_1, 0x00);  // wake up
    
    for(volatile uint16_t i=0; i<10000; i++);
    
    dev->write_reg(dev->addr, MPU6500_REG_CONFIG,        0x02); // DLPF (filter)
    dev->write_reg(dev->addr, MPU6500_REG_ACCEL_CONFIG2, 0x02); // accel DLPF (filtr)

    return true;
}

bool mpu6050_read_raw(mpu6050_dev_t *dev, mpu6050_raw_t *raw)
{
    uint8_t tmp[14];

    if (dev->read_regs(dev->addr, MPU6500_REG_ACCEL_XOUT_H, tmp, 14) != true)
    {
        return false;
    }

    raw->ax = (int16_t)((tmp[0]  << 8) | tmp[1]);
    raw->ay = (int16_t)((tmp[2]  << 8) | tmp[3]);
    raw->az = (int16_t)((tmp[4]  << 8) | tmp[5]);
    raw->gx = (int16_t)((tmp[8]  << 8) | tmp[9]);
    raw->gy = (int16_t)((tmp[10] << 8) | tmp[11]);
    raw->gz = (int16_t)((tmp[12] << 8) | tmp[13]);

    return true;
}

