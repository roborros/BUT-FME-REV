#ifndef UART_H
#define	UART_H

void uart_init(void);
void putch(char data);

#endif	/* UART_H */

