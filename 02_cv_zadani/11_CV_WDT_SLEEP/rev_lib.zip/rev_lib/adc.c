
#include <avr/io.h>
#include "adc.h"


void adc_init(void){

}

void adc_set_channel(uint8_t ch){

}

uint16_t adc_read_raw(void){


    return 0;
}

