
#include <avr/io.h>
#include "lcd.h"


void uart_init(uint32_t f_cpu, uint32_t baud){


    
}

void uart_write_byte(uint8_t data){


    
}

void uart_write_str(char *str){
    


}
