/* 
 * File:   uart.h
 * Author: adame
 *
 * Created on 12. b?ezna 2021, 15:12
 */

#ifndef UART_H
#define	UART_H

void uart_init(void);
void putch(unsigned char data);
#endif	/* UART_H */

