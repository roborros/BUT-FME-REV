#include "adc.h"


void adc_init(void){
    
    ADCON2bits.ADCS = 0b110;
    ADCON2bits.ACQT = 0b100;
    ADCON2bits.ADFM = 1;
    ADCON0bits.ADON = 1;
}

uint16_t adc_read(uint8_t channel){

    ADCON0bits.CHS = channel;
    
    GODONE = 1;
    while(GODONE){};
    
    return (uint16_t)((ADRESH << 8) | ADRESL);
    
}