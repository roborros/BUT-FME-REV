#ifndef BSP_H
#define	BSP_H

#ifdef	__cplusplus
extern "C" {
#endif
    
#include <xc.h>
#include <stdint.h>
    
#define _XTAL_FREQ 32000000
    
#define LED1 LATDbits.LATD2
#define LED2 LATDbits.LATD3
#define LED3 LATCbits.LATC4
#define LED4 LATDbits.LATD4
#define LED5 LATDbits.LATD5
#define LED6 LATDbits.LATD6

#define BTN1 PORTCbits.RC0
#define BTN2 PORTAbits.RA4
#define BTN3 PORTAbits.RA3
#define BTN4 PORTAbits.RA2
    
#define TMR1_ISR_VALUE (0xffff - 999) 
    
#define RAISING_EDGE 0b01111111
#define FALLING_EDGE 0b10000000


typedef struct {
    char btn1_acc;
   
    char btn2_acc;   
    
    char btn3_acc;
       
    char btn4_acc;
        
    char btn1_stat;
    char btn2_stat;
    char btn3_stat;
    char btn4_stat;
}btn_filter_t;    
    

void bsp_init(void);
void bsp_enable_interrupts(void);
void bsp_disable_interrupts(void);
uint32_t bsp_millis(void);
void bsp_millis_step(void);
void bsp_btn_step(void);
char bsp_btn_state(char btn);

    
#ifdef	__cplusplus
}
#endif

#endif	/* BSP_H */

