#include <xc.h>
#include <stdio.h>
#include <string.h>

#include "bsp.h"
#include "lcd.h"
#include "adc.h"
#include "uart.h"

int16_t get_temp(void);

static const char GUIDE[] =   "Navod k pouziti:\n"
                        "temp -> vraci teplotu\n"
                        "pot1 -> vraci potenciometr1\n"
                        "pot2 -> vraci potenciometr2\n";

rc_mess_t g_messege = {0};

void __interrupt(high_priority) high_isr(void){

    if(TMR1IE & TMR1IF){
        bsp_millis_step();
        TMR1 = TMR1_ISR_VALUE;
        TMR1IF = 0;
    }
    
    if(RC1IF && RC1IE){
        
        char temp = RC1REG;
        if (temp != '\n'){
            g_messege.buff[g_messege.index++] = temp;
        }
        else{
            g_messege.buff[g_messege.index] = '\0';
            g_messege.num_of_char = g_messege.index; 
            g_messege.index = 0;
        }
    }

}

void __interrupt(low_priority) low_isr(void){
     
    if (TMR2IF && TMR2IE ){
        bsp_btn_step();
        TMR2IF = 0;
    }
}

void main(void) {
    
    bsp_init();
    adc_init();
    LCD_Init();
    uart_init();
    
    bsp_enable_interrupts();
    
    char lcd_mess[17];
    uint32_t prev_time=bsp_millis();
    
    uint16_t adc;
    
    printf("%s", GUIDE);
    
    while(1){
    
        if((bsp_millis() - prev_time) >= 250){
            
            LED1 ^= 1;       
            prev_time = bsp_millis();
        }
        
        if(g_messege.num_of_char){
            
            if(strcmp("temp", g_messege.buff) == 0){
                printf("temp: %d\n", get_temp());
            }
            else if(strcmp("pot1", g_messege.buff) == 0){
                printf("pot1: %d\n", adc_read(4));
            }
            else if(strcmp("pot2", g_messege.buff) == 0){
                printf("pot2: %d\n", adc_read(5));
            }
            else{
                printf("Unknown command: %s \n", g_messege.buff);
                printf("%s \n", GUIDE);
            }
            
            g_messege.num_of_char=0;
        }
        
        if(bsp_btn_state(1)){
            printf("pot1: %d\n", adc_read(4));
        }
        
        if(bsp_btn_state(2)){
            printf("pot2: %d\n", adc_read(5));
        }
        
        if(bsp_btn_state(3)){
            printf("temp: %d\n", get_temp());
        }
        
        if(bsp_btn_state(4)){
            sprintf(lcd_mess, "adc-> %d            ", get_temp());
            LCD_ShowString(1, lcd_mess);
        }
    }
    
    return;
}


int16_t get_temp(void){
    
    uint16_t adc_mV;
    int16_t temp;
    
    adc_mV = (uint16_t)(((uint32_t)adc_read(1)*3300)>>10);
    
    temp = (int16_t)(adc_mV - 500)/10;
    return temp;
}

