#include "uart.h"
#include "bsp.h"

void uart_init(void){
 
    TRISCbits.TRISC6 = 1;  
    TRISCbits.TRISC7 = 1; 
    ANSELCbits.ANSC6 = 0;
    ANSELCbits.ANSC7 = 0;
    
    if(BRGH_USED){
        TXSTA1bits.BRGH = 1;
        SPBRG1 = (uint8_t)(_XTAL_FREQ/(16.0F*BAUDRATE))-1; 
    }else{
        SPBRG1 = (uint8_t)(_XTAL_FREQ/(64.0F*BAUDRATE))-1;  
    }
      
    RCSTA1bits.SPEN = 1;           
    TXSTA1bits.TXEN = 1;      
    RCSTA1bits.CREN = 1;
    RC1IE = 1;

}

void putch(char data){
    
    while(!TX1IF){};
    TX1REG = data;

}