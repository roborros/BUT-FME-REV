
#ifndef UART_H
#define	UART_H

#ifdef	__cplusplus
extern "C" {
#endif
    
#include <xc.h>
#include <stdint.h>

#define BAUDRATE  115200
#define BRGH_USED 1

typedef struct{
    char buff[32];
    uint8_t num_of_char;
    uint8_t index;
}rc_mess_t;

void uart_init(void);
void putch(char data);
void uart_rc_isr_handler(void);


#ifdef	__cplusplus
}
#endif

#endif	/* UART_H */

